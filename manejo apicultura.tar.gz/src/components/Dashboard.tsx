import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { STATUS_COLORS, STATUS_ORDER, type Hive, type Task, type Inspection } from "../types/hive";
import { useCountUp, useReveal } from "../hooks";

interface DashboardProps {
  hives: Hive[];
  tasks: Task[];
  inspections: Inspection[];
  onNavigate: (section: string) => void;
  onAddHive: () => void;
  onAddInspection: () => void;
  onAddTask: () => void;
  weather?: {
    temperature: number;
    condition: string;
    rainProbability: number;
  };
}

function Card({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const { ref, inView } = useReveal();
  return (
    <motion.div
      ref={ref}
      className={`reveal ${inView ? "in" : ""} card p-6 ${className}`}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
    >
      {children}
    </motion.div>
  );
}

export default function Dashboard({ 
  hives, 
  tasks, 
  inspections, 
  onNavigate, 
  onAddHive, 
  onAddInspection, 
  onAddTask,
  weather 
}: DashboardProps) {
  const { ref, inView } = useReveal();
  
  // Calcular estadísticas
  const totalHives = hives.length;
  const healthyHives = hives.filter(h => h.status === 'saludable').length;
  const healthPercentage = totalHives > 0 ? Math.round((healthyHives / totalHives) * 100) : 0;
  const healthAnim = useCountUp(healthPercentage, inView);
  
  // Producción del mes (simulada - en producción vendría de harvests)
  const monthlyProduction = 12.5; // kg
  
  // Inspecciones esta semana
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const inspectionsThisWeek = inspections.filter(i => new Date(i.date) >= weekAgo).length;
  
  // Días hasta próxima cosecha (simulado)
  const daysUntilHarvest = 15;
  
  // Alertas importantes
  const alerts = hives
    .filter(h => h.status === 'alerta' || h.status === 'sin_reina')
    .map(h => {
      const daysSinceInspection = Math.floor((now.getTime() - new Date(h.updatedAt).getTime()) / (1000 * 60 * 60 * 24));
      return {
        hive: h,
        message: h.status === 'sin_reina' 
          ? `Sin reina detectada hace ${daysSinceInspection} días`
          : `Nivel de varroa alto`,
        severity: h.status === 'sin_reina' ? 'warning' : 'danger'
      };
    });
  
  // Actividad reciente (últimas 5)
  const recentActivity = [
    ...inspections.slice(0, 3).map(i => ({
      type: 'inspection' as const,
      date: new Date(i.date),
      message: `Inspección registrada en ${hives.find(h => h.id === i.hiveId)?.code || 'colmena'}`,
      icon: '📝'
    })),
    // Simular más actividades
    {
      type: 'harvest' as const,
      date: new Date(now.getTime() - 24 * 60 * 60 * 1000),
      message: 'Cosecha de 2.3 kg en C-03',
      icon: '🍯'
    },
    {
      type: 'new_hive' as const,
      date: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000),
      message: 'Nueva colmena C-04 agregada',
      icon: '🐝'
    }
  ].sort((a, b) => b.date.getTime() - a.date.getTime()).slice(0, 5);
  
  // Próximas tareas (próximos 7 días)
  const upcomingTasks = tasks
    .filter(t => !t.completed && t.dueDate)
    .filter(t => {
      const dueDate = new Date(t.dueDate);
      const diff = dueDate.getTime() - now.getTime();
      return diff >= 0 && diff <= 7 * 24 * 60 * 60 * 1000;
    })
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 5);
  
  // Datos para mini gráfico de producción (últimos 6 meses)
  const productionData = [
    { mes: 'Jul', kg: 8.2 },
    { mes: 'Ago', kg: 10.5 },
    { mes: 'Sep', kg: 12.1 },
    { mes: 'Oct', kg: 9.8 },
    { mes: 'Nov', kg: 11.3 },
    { mes: 'Dic', kg: monthlyProduction }
  ];
  
  const formatTimeAgo = (date: Date): string => {
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (days === 0) {
      if (hours === 0) return 'Hace menos de 1 hora';
      if (hours === 1) return 'Hace 1 hora';
      return `Hace ${hours} horas`;
    }
    if (days === 1) return 'Ayer';
    return `Hace ${days} días`;
  };
  
  const formatDueDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    const diff = date.getTime() - now.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Hoy';
    if (days === 1) return 'Mañana';
    return `En ${days} días`;
  };
  
  return (
    <motion.div 
      ref={ref}
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* 1. RESUMEN RÁPIDO */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card delay={0} className="col-span-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-wider text-husk mb-2">Colmenas Activas</p>
              <p className="font-display text-4xl font-black text-cream">{totalHives}</p>
              <p className="text-xs text-husk mt-1">
                {healthyHives} saludables
              </p>
            </div>
            <div className="text-4xl">🐝</div>
          </div>
        </Card>
        
        <Card delay={0.1} className="col-span-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-wider text-husk mb-2">Producción del Mes</p>
              <p className="font-display text-4xl font-black text-honey">{monthlyProduction}</p>
              <p className="text-xs text-husk mt-1">kg de miel</p>
            </div>
            <div className="text-4xl">🍯</div>
          </div>
        </Card>
        
        <Card delay={0.2} className="col-span-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-wider text-husk mb-2">Inspecciones</p>
              <p className="font-display text-4xl font-black text-cream">{inspectionsThisWeek}</p>
              <p className="text-xs text-husk mt-1">esta semana</p>
            </div>
            <div className="text-4xl">📝</div>
          </div>
        </Card>
        
        <Card delay={0.3} className="col-span-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-wider text-husk mb-2">Próxima Cosecha</p>
              <p className="font-display text-4xl font-black text-cream">{daysUntilHarvest}</p>
              <p className="text-xs text-husk mt-1">días</p>
            </div>
            <div className="text-4xl">📅</div>
          </div>
        </Card>
      </div>
      
      {/* 2. ALERTAS IMPORTANTES */}
      <Card delay={0.4}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl font-bold text-cream">Alertas Importantes</h3>
          {alerts.length > 0 && (
            <span className="px-3 py-1 rounded-full bg-coral/20 text-coral text-xs font-semibold">
              {alerts.length} {alerts.length === 1 ? 'alerta' : 'alertas'}
            </span>
          )}
        </div>
        
        {alerts.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-5xl mb-3">✅</div>
            <p className="text-husk">Todas las colmenas en buen estado</p>
          </div>
        ) : (
          <div className="space-y-3">
            {alerts.map((alert, index) => (
              <motion.button
                key={alert.hive.id}
                onClick={() => {
                  onNavigate('colmenas');
                  // Aquí se podría seleccionar la colmena específica
                }}
                className={`w-full text-left p-4 rounded-lg border transition-all ${
                  alert.severity === 'danger'
                    ? 'bg-coral/10 border-coral/30 hover:bg-coral/20'
                    : 'bg-honey/10 border-honey/30 hover:bg-honey/20'
                }`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                whileHover={{ x: 4 }}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">
                    {alert.severity === 'danger' ? '🔴' : '⚠️'}
                  </span>
                  <div className="flex-1">
                    <p className="font-semibold text-cream mb-1">
                      Colmena {alert.hive.code}
                    </p>
                    <p className="text-sm text-husk">
                      {alert.message}
                    </p>
                  </div>
                  <svg className="w-5 h-5 text-husk" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </Card>
      
      {/* Grid de 2 columnas para las siguientes secciones */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 3. ACTIVIDAD RECIENTE */}
        <Card delay={0.6}>
          <h3 className="font-display text-xl font-bold text-cream mb-4">Actividad Reciente</h3>
          
          {recentActivity.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-5xl mb-3">📭</div>
              <p className="text-husk">No hay actividad reciente</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {recentActivity.map((activity, index) => (
                <motion.div
                  key={index}
                  className="flex items-start gap-3 pb-4 border-b border-line last:border-0 last:pb-0"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                >
                  <span className="text-2xl">{activity.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm text-cream mb-1">{activity.message}</p>
                    <p className="text-xs text-husk">{formatTimeAgo(activity.date)}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </Card>
        
        {/* 4. PRÓXIMAS TAREAS */}
        <Card delay={0.7}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-xl font-bold text-cream">Próximas Tareas</h3>
            <button
              onClick={() => onNavigate('tareas')}
              className="text-xs text-honey hover:text-honeysoft transition-colors"
            >
              Ver todas →
            </button>
          </div>
          
          {upcomingTasks.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-5xl mb-3">📋</div>
              <p className="text-husk">No hay tareas programadas</p>
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingTasks.map((task, index) => (
                <motion.div
                  key={task.id}
                  className="p-3 rounded-lg bg-ink/50 border border-line hover:border-honey/30 transition-all cursor-pointer"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                  whileHover={{ x: 4 }}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-xl">📅</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-cream mb-1">{task.title}</p>
                      <p className="text-xs text-honey">{formatDueDate(task.dueDate)}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </Card>
      </div>
      
      {/* 5. ACCESOS RÁPIDOS */}
      <Card delay={0.9}>
        <h3 className="font-display text-xl font-bold text-cream mb-4">Accesos Rápidos</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <motion.button
            onClick={onAddHive}
            className="p-6 rounded-xl bg-honey/10 border-2 border-honey/30 hover:bg-honey/20 hover:border-honey/50 transition-all text-center"
            whileHover={{ scale: 1.05, y: -4 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="text-4xl mb-2">➕</div>
            <p className="text-sm font-semibold text-cream">Nueva Colmena</p>
          </motion.button>
          
          <motion.button
            onClick={onAddInspection}
            className="p-6 rounded-xl bg-honey/10 border-2 border-honey/30 hover:bg-honey/20 hover:border-honey/50 transition-all text-center"
            whileHover={{ scale: 1.05, y: -4 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="text-4xl mb-2">📝</div>
            <p className="text-sm font-semibold text-cream">Registrar Inspección</p>
          </motion.button>
          
          <motion.button
            onClick={() => onNavigate('produccion')}
            className="p-6 rounded-xl bg-honey/10 border-2 border-honey/30 hover:bg-honey/20 hover:border-honey/50 transition-all text-center"
            whileHover={{ scale: 1.05, y: -4 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="text-4xl mb-2">🍯</div>
            <p className="text-sm font-semibold text-cream">Registrar Cosecha</p>
          </motion.button>
          
          <motion.button
            onClick={onAddTask}
            className="p-6 rounded-xl bg-honey/10 border-2 border-honey/30 hover:bg-honey/20 hover:border-honey/50 transition-all text-center"
            whileHover={{ scale: 1.05, y: -4 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="text-4xl mb-2">📅</div>
            <p className="text-sm font-semibold text-cream">Agregar Tarea</p>
          </motion.button>
        </div>
      </Card>
      
      {/* Grid de 2 columnas para gráfico y clima */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 6. MINI GRÁFICO DE PRODUCCIÓN */}
        <Card delay={1.0}>
          <h3 className="font-display text-xl font-bold text-cream mb-4">Producción Últimos 6 Meses</h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productionData}>
                <XAxis dataKey="mes" stroke="#a3906a" style={{ fontSize: '12px' }} />
                <YAxis stroke="#a3906a" style={{ fontSize: '12px' }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1b140c', 
                    border: '1px solid #392c19',
                    borderRadius: '8px',
                    color: '#f3e9d4'
                  }}
                />
                <Bar dataKey="kg" fill="#f0a41c" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        
        {/* 7. CLIMA DEL APIARIO */}
        <Card delay={1.1}>
          <h3 className="font-display text-xl font-bold text-cream mb-4">Clima del Apiario</h3>
          
          {weather ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-display text-5xl font-black text-cream">{weather.temperature}°C</p>
                  <p className="text-sm text-husk mt-1">{weather.condition}</p>
                </div>
                <div className="text-6xl">
                  {weather.condition.toLowerCase().includes('sol') ? '☀️' : 
                   weather.condition.toLowerCase().includes('nublado') ? '☁️' : 
                   weather.condition.toLowerCase().includes('lluvia') ? '🌧️' : '⛅'}
                </div>
              </div>
              
              <div className="pt-4 border-t border-line">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">💧</span>
                  <div>
                    <p className="text-xs text-husk">Probabilidad de lluvia</p>
                    <p className="text-lg font-semibold text-cream">{weather.rainProbability}%</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-5xl mb-3">🌤️</div>
              <p className="text-husk">Datos climáticos no disponibles</p>
              <p className="text-xs text-husk mt-2">Configura la ubicación en Ajustes</p>
            </div>
          )}
        </Card>
      </div>
      
      {/* 8. ESTADO DEL COLMENAR (mantener el original) */}
      <Card delay={1.2}>
        <motion.p className="tick-label" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.3 }}>
          Estado General del Colmenar
        </motion.p>
        
        <motion.div className="mt-3 flex items-end gap-3" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1.4, type: "spring", stiffness: 200 }}>
          <span className="font-display text-6xl font-black leading-none text-cream sm:text-7xl">{healthAnim}</span>
          <span className="font-display text-3xl font-bold text-honey">%</span>
          <span className="pb-1.5 text-sm text-husk">de colmenas en forma</span>
        </motion.div>
        
        <motion.div className="mt-5 flex h-3 overflow-hidden rounded-full border border-line bg-ink" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1.5, duration: 0.8 }} style={{ transformOrigin: 'left' }}>
          {STATUS_ORDER.map((s, index) => {
            const count = hives.filter(h => h.status === s).length;
            const percentage = totalHives > 0 ? (count / totalHives) * 100 : 0;
            return percentage > 0 && (
              <motion.div
                key={s}
                className="h-full"
                style={{ width: `${percentage}%`, background: STATUS_COLORS[s] }}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 1.5 + index * 0.1, duration: 0.8 }}
              />
            );
          })}
        </motion.div>
        
        <motion.div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.7 }}>
          {STATUS_ORDER.map((s, index) => {
            const count = hives.filter(h => h.status === s).length;
            return (
              <motion.div key={s} className="flex items-center gap-2" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.7 + index * 0.1 }}>
                <span className="h-3 w-3 rounded-[3px]" style={{ background: STATUS_COLORS[s] }} />
                <span className="text-xs text-husk">
                  {s === 'saludable' ? 'Saludable' : s === 'revision' ? 'Revisión' : s === 'alerta' ? 'Alerta' : 'Sin reina'}
                </span>
                <span className="ml-auto font-mono text-sm font-bold text-cream">{count}</span>
              </motion.div>
            );
          })}
        </motion.div>
      </Card>
    </motion.div>
  );
}
