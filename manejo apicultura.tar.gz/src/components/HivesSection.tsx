import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { STATUS_COLORS, STATUS_ORDER, type Hive, type HiveStatus, type QueenMarkColor } from "../types/hive";
import { useReveal } from "../hooks";
import HiveComb from './HiveComb';
import HiveDetail from './HiveDetail';

interface HivesSectionProps {
  hives: Hive[];
  selectedId: string;
  onSelect: (id: string) => void;
  filter: HiveStatus | "todas";
  onFilter: (f: HiveStatus | "todas") => void;
  onAddHive: () => void;
  onEditHive: (hive: Hive) => void;
  onDeleteHive: (id: string) => void;
  onInspect: (id: string) => void;
  onShowToast: (message: string, type: 'success' | 'error') => void;
}

type SortOption = 'code' | 'lastInspection' | 'status' | 'health';
type ViewMode = 'map' | 'list';

export default function HivesSection({
  hives,
  selectedId,
  onSelect,
  filter,
  onFilter,
  onAddHive,
  onEditHive,
  onDeleteHive,
  onInspect,
  onShowToast,
}: HivesSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('code');
  const [viewMode, setViewMode] = useState<ViewMode>('map');
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('hive_favorites');
    return saved ? JSON.parse(saved) : [];
  });
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [compareMode, setCompareMode] = useState(false);
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);
  const [tags, setTags] = useState<Record<string, string[]>>(() => {
    const saved = localStorage.getItem('hive_tags');
    return saved ? JSON.parse(saved) : {};
  });
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [groupByLocation, setGroupByLocation] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());

  // Persistir favoritos
  useEffect(() => {
    localStorage.setItem('hive_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Persistir etiquetas
  useEffect(() => {
    localStorage.setItem('hive_tags', JSON.stringify(tags));
  }, [tags]);

  // Calcular salud de colmena
  const calculateHealth = (hive: Hive): number => {
    let health = 100;
    
    // Días desde última inspección
    const daysSinceInspection = Math.floor(
      (Date.now() - new Date(hive.updatedAt).getTime()) / (1000 * 60 * 60 * 24)
    );
    if (daysSinceInspection > 30) health -= 40;
    else if (daysSinceInspection > 14) health -= 20;
    else if (daysSinceInspection > 7) health -= 10;
    
    // Estado
    if (hive.status === 'alerta') health -= 30;
    else if (hive.status === 'sin_reina') health -= 50;
    else if (hive.status === 'revision') health -= 15;
    
    return Math.max(0, Math.min(100, health));
  };

  // Filtrar y ordenar colmenas
  const filteredAndSortedHives = useMemo(() => {
    let result = [...hives];
    
    // Filtro por búsqueda
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      result = result.filter(h => 
        h.code.toLowerCase().includes(query) ||
        (h.name && h.name.toLowerCase().includes(query))
      );
    }
    
    // Filtro por estado
    if (filter !== 'todas') {
      result = result.filter(h => h.status === filter);
    }
    
    // Filtro por favoritos
    if (showFavoritesOnly) {
      result = result.filter(h => favorites.includes(h.id));
    }
    
    // Filtro por etiqueta
    if (selectedTag) {
      result = result.filter(h => tags[h.id]?.includes(selectedTag));
    }
    
    // Ordenar
    result.sort((a, b) => {
      // Favoritos primero
      const aFav = favorites.includes(a.id);
      const bFav = favorites.includes(b.id);
      if (aFav && !bFav) return -1;
      if (!aFav && bFav) return 1;
      
      switch (sortBy) {
        case 'code':
          return a.code.localeCompare(b.code);
        case 'lastInspection':
          return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
        case 'status':
          const statusOrder = { alerta: 0, sin_reina: 1, revision: 2, saludable: 3 };
          return statusOrder[a.status] - statusOrder[b.status];
        case 'health':
          return calculateHealth(b) - calculateHealth(a);
        default:
          return 0;
      }
    });
    
    return result;
  }, [hives, searchQuery, filter, sortBy, showFavoritesOnly, favorites, selectedTag, tags]);

  // Agrupar por ubicación
  const groupedHives = useMemo(() => {
    if (!groupByLocation) return null;
    
    const groups: Record<string, Hive[]> = {};
    filteredAndSortedHives.forEach(hive => {
      const location = hive.location || 'Sin ubicación';
      if (!groups[location]) groups[location] = [];
      groups[location].push(hive);
    });
    
    return groups;
  }, [filteredAndSortedHives, groupByLocation]);

  // Estadísticas rápidas
  const quickStats = useMemo(() => {
    if (filteredAndSortedHives.length === 0) return null;
    
    const avgDaysSinceInspection = Math.round(
      filteredAndSortedHives.reduce((sum, h) => {
        const days = Math.floor((Date.now() - new Date(h.updatedAt).getTime()) / (1000 * 60 * 60 * 24));
        return sum + days;
      }, 0) / filteredAndSortedHives.length
    );
    
    return {
      total: filteredAndSortedHives.length,
      avgDaysSinceInspection,
      healthy: filteredAndSortedHives.filter(h => h.status === 'saludable').length,
      alerts: filteredAndSortedHives.filter(h => h.status === 'alerta').length,
    };
  }, [filteredAndSortedHives]);

  // Toggle favorito
  const toggleFavorite = (hiveId: string) => {
    setFavorites(prev => 
      prev.includes(hiveId) 
        ? prev.filter(id => id !== hiveId)
        : [...prev, hiveId]
    );
  };

  // Toggle etiqueta
  const toggleTag = (hiveId: string, tag: string) => {
    setTags(prev => {
      const current = prev[hiveId] || [];
      const updated = current.includes(tag)
        ? current.filter(t => t !== tag)
        : [...current, tag];
      return { ...prev, [hiveId]: updated };
    });
  };

  // Duplicar colmena
  const duplicateHive = (hive: Hive) => {
    const maxNum = hives.reduce((max, h) => {
      const match = h.code.match(/C-(\d+)/);
      return match ? Math.max(max, parseInt(match[1])) : max;
    }, 0);
    
    const newCode = `C-${(maxNum + 1).toString().padStart(2, '0')}`;
    const newHive: Hive = {
      ...hive,
      id: crypto.randomUUID(),
      code: newCode,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    // Aquí deberías llamar a la función de agregar colmena
    onShowToast(`Colmena duplicada como ${newCode}`, 'success');
  };

  // Exportar ficha
  const exportHive = (hive: Hive) => {
    const text = `Colmena ${hive.code}${hive.name ? ` - ${hive.name}` : ''}
Estado: ${hive.status}
${hive.queenYear ? `Reina: ${hive.queenYear}${hive.queenMarkColor ? ` (${hive.queenMarkColor})` : ''}` : ''}
${hive.location ? `Ubicación: ${hive.location}` : ''}
Última inspección: ${new Date(hive.updatedAt).toLocaleDateString('es-ES')}
${hive.notes ? `Notas: ${hive.notes}` : ''}`;
    
    navigator.clipboard.writeText(text);
    onShowToast('Ficha copiada al portapapeles', 'success');
  };

  // Comparar colmenas
  const toggleCompare = (hiveId: string) => {
    setSelectedForCompare(prev => 
      prev.includes(hiveId)
        ? prev.filter(id => id !== hiveId)
        : prev.length < 3 ? [...prev, hiveId] : prev
    );
  };

  // Toggle grupo expandido
  const toggleGroup = (location: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(location)) newSet.delete(location);
      else newSet.add(location);
      return newSet;
    });
  };

  const selectedHive = hives.find(h => h.id === selectedId);

  return (
    <div className="space-y-6">
      {/* Estadísticas rápidas */}
      {quickStats && (
        <motion.div 
          className="grid grid-cols-2 lg:grid-cols-4 gap-3"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="card p-4">
            <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Total</p>
            <p className="font-display text-2xl font-black text-cream">{quickStats.total}</p>
          </div>
          <div className="card p-4">
            <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Promedio Inspección</p>
            <p className="font-display text-2xl font-black text-honey">{quickStats.avgDaysSinceInspection}d</p>
          </div>
          <div className="card p-4">
            <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Saludables</p>
            <p className="font-display text-2xl font-black text-sage">{quickStats.healthy}</p>
          </div>
          <div className="card p-4">
            <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Alertas</p>
            <p className="font-display text-2xl font-black text-coral">{quickStats.alerts}</p>
          </div>
        </motion.div>
      )}

      {/* Controles superiores */}
      <div className="space-y-4">
        {/* Barra de búsqueda */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por código o nombre..."
            className="w-full rounded-xl border border-line bg-ink/50 pl-12 pr-12 py-3 text-sm text-cream placeholder:text-husk/60 focus:border-honey/70 focus:shadow-[0_0_0_3px_rgba(240,164,28,.12)]"
          />
          <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-husk" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-husk/20 hover:bg-husk/40 flex items-center justify-center transition-colors"
            >
              <svg className="w-4 h-4 text-cream" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>

        {/* Controles de ordenamiento y vista */}
        <div className="flex flex-wrap gap-3">
          {/* Ordenamiento */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortOption)}
            className="rounded-xl border border-line bg-ink/50 px-4 py-2.5 text-sm text-cream focus:border-honey/70"
          >
            <option value="code">Ordenar: Código</option>
            <option value="lastInspection">Ordenar: Última inspección</option>
            <option value="status">Ordenar: Estado</option>
            <option value="health">Ordenar: Salud</option>
          </select>

          {/* Toggle vista */}
          <div className="flex rounded-xl border border-line overflow-hidden">
            <button
              onClick={() => setViewMode('map')}
              className={`px-4 py-2.5 text-sm font-medium transition-colors ${
                viewMode === 'map' ? 'bg-honey text-ink' : 'bg-ink/50 text-husk hover:text-cream'
              }`}
            >
              Mapa
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2.5 text-sm font-medium transition-colors ${
                viewMode === 'list' ? 'bg-honey text-ink' : 'bg-ink/50 text-husk hover:text-cream'
              }`}
            >
              Lista
            </button>
          </div>

          {/* Favoritos */}
          <button
            onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
            className={`px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors ${
              showFavoritesOnly 
                ? 'border-honey bg-honey/20 text-honey' 
                : 'border-line bg-ink/50 text-husk hover:text-cream'
            }`}
          >
            ⭐ Favoritas {favorites.length > 0 && `(${favorites.length})`}
          </button>

          {/* Comparar */}
          <button
            onClick={() => {
              setCompareMode(!compareMode);
              setSelectedForCompare([]);
            }}
            className={`px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors ${
              compareMode 
                ? 'border-honey bg-honey/20 text-honey' 
                : 'border-line bg-ink/50 text-husk hover:text-cream'
            }`}
          >
            {compareMode ? '✓ Comparando' : '⚖️ Comparar'}
          </button>

          {/* Agrupar por ubicación */}
          <button
            onClick={() => setGroupByLocation(!groupByLocation)}
            className={`px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors ${
              groupByLocation 
                ? 'border-honey bg-honey/20 text-honey' 
                : 'border-line bg-ink/50 text-husk hover:text-cream'
            }`}
          >
            📍 Agrupar
          </button>
        </div>
      </div>

      {/* Vista de colmenas */}
      {viewMode === 'map' ? (
        <HiveComb
          hives={filteredAndSortedHives}
          selectedId={selectedId}
          onSelect={onSelect}
          filter="todas"
          onFilter={() => {}}
          query=""
          onAdd={onAddHive}
          favorites={favorites}
          onToggleFavorite={toggleFavorite}
          compareMode={compareMode}
          selectedForCompare={selectedForCompare}
          onToggleCompare={toggleCompare}
          calculateHealth={calculateHealth}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAndSortedHives.map((hive) => {
            const health = calculateHealth(hive);
            const daysSinceInspection = Math.floor(
              (Date.now() - new Date(hive.updatedAt).getTime()) / (1000 * 60 * 60 * 24)
            );
            const isFavorite = favorites.includes(hive.id);
            const isSelectedForCompare = selectedForCompare.includes(hive.id);

            return (
              <motion.div
                key={hive.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className={`card p-4 cursor-pointer transition-all ${
                  selectedId === hive.id ? 'ring-2 ring-honey' : ''
                } ${compareMode && isSelectedForCompare ? 'ring-2 ring-honeysoft' : ''}`}
                onClick={() => !compareMode && onSelect(hive.id)}
                whileHover={{ y: -4 }}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-display text-xl font-bold text-cream">{hive.code}</h3>
                    {hive.name && <p className="text-xs text-husk">{hive.name}</p>}
                  </div>
                  <div className="flex gap-2">
                    {compareMode && (
                      <input
                        type="checkbox"
                        checked={isSelectedForCompare}
                        onChange={(e) => {
                          e.stopPropagation();
                          toggleCompare(hive.id);
                        }}
                        className="w-5 h-5"
                      />
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(hive.id);
                      }}
                      className={`text-xl transition-transform ${isFavorite ? 'scale-110' : 'opacity-50 hover:opacity-100'}`}
                    >
                      {isFavorite ? '⭐' : '☆'}
                    </button>
                  </div>
                </div>

                {/* Estado */}
                <div className="flex items-center gap-2 mb-3">
                  <span
                    className="px-2 py-1 rounded-full text-xs font-semibold"
                    style={{ 
                      background: STATUS_COLORS[hive.status] + '20',
                      color: STATUS_COLORS[hive.status],
                      border: `1px solid ${STATUS_COLORS[hive.status]}`
                    }}
                  >
                    {hive.status === 'sin_reina' ? 'Sin reina' : hive.status.charAt(0).toUpperCase() + hive.status.slice(1)}
                  </span>
                </div>

                {/* Indicador de salud */}
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-husk">Salud</span>
                    <span className="text-xs font-semibold" style={{ 
                      color: health >= 80 ? '#a3bf7f' : health >= 50 ? '#f0a41c' : '#e4603f'
                    }}>
                      {health}%
                    </span>
                  </div>
                  <div className="h-2 bg-ink rounded-full overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      style={{ 
                        background: health >= 80 ? '#a3bf7f' : health >= 50 ? '#f0a41c' : '#e4603f',
                        width: `${health}%`
                      }}
                      initial={{ width: 0 }}
                      animate={{ width: `${health}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>

                {/* Info */}
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-husk">Última inspección:</span>
                    <span className={`font-semibold ${daysSinceInspection > 14 ? 'text-coral' : 'text-cream'}`}>
                      {daysSinceInspection} días
                      {daysSinceInspection > 14 && ' ⚠️'}
                    </span>
                  </div>
                  {hive.queenYear && (
                    <div className="flex justify-between">
                      <span className="text-husk">Reina:</span>
                      <span className="text-cream">{hive.queenYear}</span>
                    </div>
                  )}
                  {hive.location && (
                    <div className="flex justify-between">
                      <span className="text-husk">Ubicación:</span>
                      <span className="text-cream truncate ml-2">{hive.location}</span>
                    </div>
                  )}
                </div>

                {/* Etiquetas */}
                {tags[hive.id] && tags[hive.id].length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-3">
                    {tags[hive.id].map(tag => (
                      <span key={tag} className="px-2 py-0.5 rounded-full bg-honey/10 text-honey text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Tabla de comparación */}
      {compareMode && selectedForCompare.length >= 2 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card p-6"
        >
          <h3 className="font-display text-xl font-bold text-cream mb-4">Comparación de Colmenas</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line">
                  <th className="text-left py-2 text-husk">Métrica</th>
                  {selectedForCompare.map(id => {
                    const hive = hives.find(h => h.id === id);
                    return hive ? (
                      <th key={id} className="text-left py-2 text-cream">{hive.code}</th>
                    ) : null;
                  })}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-line/50">
                  <td className="py-2 text-husk">Estado</td>
                  {selectedForCompare.map(id => {
                    const hive = hives.find(h => h.id === id);
                    return hive ? (
                      <td key={id} className="py-2">
                        <span style={{ color: STATUS_COLORS[hive.status] }}>
                          {hive.status}
                        </span>
                      </td>
                    ) : null;
                  })}
                </tr>
                <tr className="border-b border-line/50">
                  <td className="py-2 text-husk">Salud</td>
                  {selectedForCompare.map(id => {
                    const hive = hives.find(h => h.id === id);
                    return hive ? (
                      <td key={id} className="py-2 text-cream">
                        {calculateHealth(hive)}%
                      </td>
                    ) : null;
                  })}
                </tr>
                <tr className="border-b border-line/50">
                  <td className="py-2 text-husk">Reina</td>
                  {selectedForCompare.map(id => {
                    const hive = hives.find(h => h.id === id);
                    return hive ? (
                      <td key={id} className="py-2 text-cream">
                        {hive.queenYear || 'N/A'}
                      </td>
                    ) : null;
                  })}
                </tr>
                <tr>
                  <td className="py-2 text-husk">Días sin inspección</td>
                  {selectedForCompare.map(id => {
                    const hive = hives.find(h => h.id === id);
                    return hive ? (
                      <td key={id} className="py-2 text-cream">
                        {Math.floor((Date.now() - new Date(hive.updatedAt).getTime()) / (1000 * 60 * 60 * 24))}
                      </td>
                    ) : null;
                  })}
                </tr>
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {/* Ficha detallada */}
      {selectedHive && !compareMode && (
        <HiveDetail
          hive={selectedHive}
          inspections={[]}
          totalHives={hives.length}
          onInspect={onInspect}
          onEdit={onEditHive}
          onDelete={onDeleteHive}
          onShowToast={onShowToast}
          onDuplicate={duplicateHive}
          onExport={exportHive}
          tags={tags[selectedHive.id] || []}
          onToggleTag={(tag: string) => toggleTag(selectedHive.id, tag)}
        />
      )}
    </div>
  );
}
