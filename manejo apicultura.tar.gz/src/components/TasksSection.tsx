import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import type { Task } from "../types/hive";
import { IconCheck, IconPlus, IconCalendar } from "../ui";

interface Props {
  tasks: Task[];
  onToggle: (id: string) => void;
  onAdd: (title: string) => void;
}

const PRIORITY_COLOR: Record<Task['priority'], string> = {
  alta: "#e4603f",
  media: "#f0a41c",
  baja: "#a3906a",
};

const PRIORITY_LABEL: Record<Task['priority'], string> = {
  alta: "Alta",
  media: "Media",
  baja: "Baja",
};

export default function TasksSection({ tasks, onToggle, onAdd }: Props) {
  const [draft, setDraft] = useState("");
  const [filter, setFilter] = useState<"all" | "pending" | "completed">("all");
  const [sortBy, setSortBy] = useState<"date" | "priority">("priority");

  const done = tasks.filter((t) => t.completed).length;
  const pending = tasks.filter((t) => !t.completed);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const title = draft.trim();
    if (!title) return;
    onAdd(title);
    setDraft("");
  };

  // Filtrar tareas
  const filteredTasks = tasks.filter((t) => {
    if (filter === "pending") return !t.completed;
    if (filter === "completed") return t.completed;
    return true;
  });

  // Ordenar tareas
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    // Primero las no completadas
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    
    if (sortBy === "priority") {
      const priorityOrder = { alta: 0, media: 1, baja: 2 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }
    
    // Ordenar por fecha
    if (a.dueDate && b.dueDate) {
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    }
    return 0;
  });

  const formatDueDate = (dateStr: string | null): string => {
    if (!dateStr) return "Sin fecha";
    const date = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diff = Math.floor((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diff === 0) return "Hoy";
    if (diff === 1) return "Mañana";
    if (diff === -1) return "Ayer";
    if (diff < 0) return `Hace ${Math.abs(diff)} días`;
    if (diff <= 7) return `En ${diff} días`;
    return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
  };

  const isOverdue = (dateStr: string | null): boolean => {
    if (!dateStr) return false;
    const date = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  return (
    <div className="space-y-6">
      {/* Estadísticas rápidas */}
      <motion.div
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="card p-4">
          <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Total Tareas</p>
          <p className="font-display text-3xl font-black text-cream">{tasks.length}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Pendientes</p>
          <p className="font-display text-3xl font-black text-honey">{pending.length}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Completadas</p>
          <p className="font-display text-3xl font-black text-sage">{done}</p>
        </div>
        <div className="card p-4">
          <p className="text-xs font-mono uppercase tracking-wider text-husk mb-1">Progreso</p>
          <p className="font-display text-3xl font-black text-cream">
            {tasks.length > 0 ? Math.round((done / tasks.length) * 100) : 0}%
          </p>
        </div>
      </motion.div>

      {/* Barra de progreso general */}
      <motion.div
        className="card p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display text-lg font-bold text-cream">Progreso General</h3>
          <span className="font-display text-2xl font-black text-honey">
            {tasks.length > 0 ? Math.round((done / tasks.length) * 100) : 0}%
          </span>
        </div>
        <div className="h-3 overflow-hidden rounded-full bg-ink">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-honey to-honeysoft"
            initial={{ width: 0 }}
            animate={{ width: `${tasks.length > 0 ? (done / tasks.length) * 100 : 0}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        </div>
      </motion.div>

      {/* Controles */}
      <motion.div
        className="flex flex-wrap gap-3"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {/* Filtros */}
        <div className="flex rounded-xl border border-line overflow-hidden">
          <button
            onClick={() => setFilter("all")}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              filter === "all" ? "bg-honey text-ink" : "bg-ink/50 text-husk hover:text-cream"
            }`}
          >
            Todas
          </button>
          <button
            onClick={() => setFilter("pending")}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              filter === "pending" ? "bg-honey text-ink" : "bg-ink/50 text-husk hover:text-cream"
            }`}
          >
            Pendientes
          </button>
          <button
            onClick={() => setFilter("completed")}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              filter === "completed" ? "bg-honey text-ink" : "bg-ink/50 text-husk hover:text-cream"
            }`}
          >
            Completadas
          </button>
        </div>

        {/* Ordenamiento */}
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as "date" | "priority")}
          className="rounded-xl border border-line bg-ink/50 px-4 py-2 text-sm text-cream focus:border-honey/70"
        >
          <option value="priority">Ordenar: Prioridad</option>
          <option value="date">Ordenar: Fecha</option>
        </select>
      </motion.div>

      {/* Lista de tareas */}
      <motion.div
        className="card p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <div className="mb-5 flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-line bg-ink text-honey">
            <IconCheck className="h-5 w-5" />
          </span>
          <div className="flex-1">
            <h3 className="font-display text-xl font-bold text-cream">Tareas del Colmenar</h3>
            <p className="font-mono text-[10px] uppercase tracking-widest text-husk">
              {done}/{tasks.length} completadas
            </p>
          </div>
        </div>

        {sortedTasks.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-5xl mb-3">📋</div>
            <p className="text-husk">No hay tareas</p>
            <p className="text-xs text-husk mt-2">
              {filter === "pending" ? "No hay tareas pendientes" : 
               filter === "completed" ? "No hay tareas completadas" : 
               "Agrega tu primera tarea"}
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-line">
            {sortedTasks.map((task, index) => (
              <motion.li
                key={task.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <button
                  onClick={() => onToggle(task.id)}
                  className="group flex w-full items-start gap-3.5 py-3.5 text-left hover:bg-pane2/40 transition-colors rounded-lg px-2 -mx-2"
                >
                  <span
                    className="hexclip mt-0.5 flex h-[22px] w-5 shrink-0 items-center justify-center transition-all duration-200 group-hover:scale-110"
                    style={{ background: task.completed ? "#f0a41c" : "#2d2214" }}
                  >
                    {task.completed && <IconCheck className="h-3 w-3 text-ink" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={`block text-sm font-medium transition-all duration-300 ${
                      task.completed ? "text-husk line-through" : "text-cream"
                    }`}>
                      {task.title}
                    </span>
                    <span className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[10px] uppercase tracking-wider text-husk">
                      <span className="flex items-center gap-1.5">
                        <span className="h-1.5 w-1.5 rounded-full" style={{ background: PRIORITY_COLOR[task.priority] }} />
                        {PRIORITY_LABEL[task.priority]}
                      </span>
                      {task.dueDate && (
                        <span className={`flex items-center gap-1 ${
                          !task.completed && isOverdue(task.dueDate) ? "text-coral" : ""
                        }`}>
                          <IconCalendar className="h-3 w-3" />
                          {formatDueDate(task.dueDate)}
                          {!task.completed && isOverdue(task.dueDate) && " ⚠️"}
                        </span>
                      )}
                    </span>
                  </span>
                </button>
              </motion.li>
            ))}
          </ul>
        )}
      </motion.div>

      {/* Formulario para agregar tarea */}
      <motion.form
        onSubmit={submit}
        className="card p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <div className="mb-4 flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-line bg-ink text-honey">
            <IconPlus className="h-5 w-5" />
          </span>
          <div>
            <h3 className="font-display text-lg font-bold text-cream">Agregar Nueva Tarea</h3>
            <p className="font-mono text-[10px] uppercase tracking-widest text-husk">
              Crea una nueva tarea para tu colmenar
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Ej: Revisar colmena C-03, Aplicar tratamiento varroa..."
            className="min-w-0 flex-1 rounded-xl border border-line bg-ink px-4 py-3 text-sm text-cream placeholder:text-husk/60 transition-colors focus:border-honey/70 focus:shadow-[0_0_0_3px_rgba(240,164,28,.12)]"
          />
          <motion.button
            type="submit"
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-honey text-ink transition-all hover:bg-honeysoft active:scale-95"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <IconPlus className="h-5 w-5" />
          </motion.button>
        </div>
      </motion.form>
    </div>
  );
}
