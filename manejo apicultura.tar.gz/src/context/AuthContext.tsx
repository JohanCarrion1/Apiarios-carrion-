import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  User,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged
} from 'firebase/auth';
import { auth, googleProvider, facebookProvider, githubProvider, translateFirebaseError } from '../lib/firebase';
import { setCurrentUserId } from '../utils/storage';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithFacebook: () => Promise<void>;
  loginWithGithub: () => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Detectar sesión activa al recargar y actualizar el UID
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      console.log('🔐 Estado de autenticación cambiado:', user ? user.uid : 'null');
      setUser(user);
      
      // Actualizar el UID en storage
      if (user) {
        setCurrentUserId(user.uid);
        console.log('✅ UID establecido para usuario:', user.uid);
      } else {
        setCurrentUserId(null);
        console.log('🚪 Usuario cerró sesión, UID limpiado');
      }
      
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Login con email y contraseña
  const login = async (email: string, password: string) => {
    try {
      setError(null);
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      const errorMessage = translateFirebaseError(error.code);
      setError(errorMessage);
      throw new Error(errorMessage);
    }
  };

  // Registro con email y contraseña
  const register = async (email: string, password: string) => {
    try {
      setError(null);
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      const errorMessage = translateFirebaseError(error.code);
      setError(errorMessage);
      throw new Error(errorMessage);
    }
  };

  // Login con Google
  const loginWithGoogle = async () => {
    try {
      setError(null);
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      const errorMessage = translateFirebaseError(error.code);
      setError(errorMessage);
      throw new Error(errorMessage);
    }
  };

  // Login con Facebook
  const loginWithFacebook = async () => {
    try {
      setError(null);
      await signInWithPopup(auth, facebookProvider);
    } catch (error: any) {
      const errorMessage = translateFirebaseError(error.code);
      setError(errorMessage);
      throw new Error(errorMessage);
    }
  };

  // Login con GitHub
  const loginWithGithub = async () => {
    try {
      setError(null);
      await signInWithPopup(auth, githubProvider);
    } catch (error: any) {
      const errorMessage = translateFirebaseError(error.code);
      setError(errorMessage);
      throw new Error(errorMessage);
    }
  };

  // Cerrar sesión
  const logout = async () => {
    try {
      setError(null);
      await signOut(auth);
    } catch (error: any) {
      const errorMessage = translateFirebaseError(error.code);
      setError(errorMessage);
      throw new Error(errorMessage);
    }
  };

  // Limpiar error
  const clearError = () => setError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        error,
        login,
        register,
        loginWithGoogle,
        loginWithFacebook,
        loginWithGithub,
        logout,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
