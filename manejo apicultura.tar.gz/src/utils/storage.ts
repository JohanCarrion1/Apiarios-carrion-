// Funciones de almacenamiento con separación por usuario
import { auth } from '../lib/firebase';

// Variable global para almacenar el UID actual
let currentUserId: string | null = null;

// Obtener el UID del usuario actual
export const getUserId = (): string => {
  // Si ya tenemos el UID cacheado, retornarlo
  if (currentUserId) {
    console.log('🔑 Usando UID cacheado:', currentUserId);
    return currentUserId;
  }
  
  // Intentar obtener del usuario autenticado de Firebase
  if (auth.currentUser) {
    currentUserId = auth.currentUser.uid;
    console.log('🔑 UID obtenido de Firebase:', currentUserId);
    return currentUserId;
  }
  
  // Si no hay usuario de Firebase, retornar 'anonymous'
  console.warn('⚠️ No hay usuario autenticado, usando anonymous');
  return 'anonymous';
};

// Establecer el UID del usuario actual (llamado desde AuthContext)
export const setCurrentUserId = (uid: string | null) => {
  currentUserId = uid;
  console.log('🔑 UID actualizado:', uid);
};

// Establecer el UID del usuario (llamado desde AuthContext)
export const setUserId = (uid: string) => {
  if (uid === 'demo-user') {
    localStorage.setItem('demo_user', 'true');
  } else {
    localStorage.removeItem('demo_user');
  }
};

// Limpiar el UID del usuario (llamado al cerrar sesión)
export const clearUserId = () => {
  localStorage.removeItem('demo_user');
};

// Funciones genéricas con prefijo de usuario
export const saveToStorage = <T>(key: string, data: T): void => {
  try {
    const uid = getUserId();
    const storageKey = `${key}_${uid}`;
    console.log(`💾 Guardando ${key} para usuario ${uid}:`, data);
    localStorage.setItem(storageKey, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
};

export const loadFromStorage = <T>(key: string): T | null => {
  try {
    const uid = getUserId();
    const storageKey = `${key}_${uid}`;
    const item = localStorage.getItem(storageKey);
    const data = item ? JSON.parse(item) : null;
    console.log(`📂 Cargando ${key} para usuario ${uid}:`, data);
    return data;
  } catch (error) {
    console.error('Error loading from localStorage:', error);
    return null;
  }
};

export const removeFromStorage = (key: string): void => {
  try {
    const uid = getUserId();
    const storageKey = `${key}_${uid}`;
    localStorage.removeItem(storageKey);
  } catch (error) {
    console.error('Error removing from localStorage:', error);
  }
};

// Funciones específicas para colmenas
export const saveHives = (hives: any[]) => saveToStorage('hives', hives);
export const loadHives = () => loadFromStorage<any[]>('hives') || [];

// Funciones específicas para inspecciones
export const saveInspections = (inspections: any[]) => saveToStorage('inspections', inspections);
export const loadInspections = () => loadFromStorage<any[]>('inspections') || [];

// Funciones específicas para cosechas
export const saveHarvests = (harvests: any[]) => saveToStorage('harvests', harvests);
export const loadHarvests = () => loadFromStorage<any[]>('harvests') || [];

// Funciones específicas para tareas
export const saveTasks = (tasks: any[]) => saveToStorage('tasks', tasks);
export const loadTasks = () => loadFromStorage<any[]>('tasks') || [];

// Funciones específicas para eventos
export const saveEvents = (events: any[]) => saveToStorage('events', events);
export const loadEvents = () => loadFromStorage<any[]>('events') || [];

// Funciones específicas para configuración
export const saveSettings = (settings: any) => saveToStorage('settings', settings);
export const loadSettings = () => loadFromStorage<any>('settings');

// Funciones específicas para favoritos
export const saveFavorites = (favorites: string[]) => saveToStorage('favorites', favorites);
export const loadFavorites = () => loadFromStorage<string[]>('favorites') || [];

// Funciones específicas para etiquetas
export const saveTags = (tags: Record<string, string[]>) => saveToStorage('tags', tags);
export const loadTags = () => loadFromStorage<Record<string, string[]>>('tags') || {};
